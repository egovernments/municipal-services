package org.egov.nod.web.models;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.egov.nod.web.models.ResponseInfo.StatusEnum;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RequestInfo {
	 @JsonProperty("apiId")
	    @NotNull
	    @Size(max = 128)
	    private String apiId = null;

	    @JsonProperty("ver")
	    @NotNull
	    @Size(max = 32)
	    private String ver = null;

	    @JsonProperty("ts")
	    @NotNull
	    private Long ts = 0L;
	    
	    @JsonProperty("resMsgId")
	    @Size(max = 256)
	    private String resMsgId = null;

	    @JsonProperty("msgId")
	    @Size(max = 256)
	    private String msgId = null;
	    
	   
	    
	
}
