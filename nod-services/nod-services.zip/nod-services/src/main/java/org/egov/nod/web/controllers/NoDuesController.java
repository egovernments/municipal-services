package org.egov.nod.web.controllers;

import javax.validation.Valid;

import org.egov.nod.models.NoDuesDetails;
import org.egov.nod.service.NoDuesService;
import org.egov.nod.utils.ResponseInfoFactory;
import org.egov.nod.web.models.NoDuesCreateRequest;
import org.egov.nod.web.models.NoDuesCreateResponse;
import org.egov.nod.web.models.ResponseInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/nodues")
public class NoDuesController {

	@Autowired
	NoDuesService noDuesService;
	
	
	
	 @RequestMapping(value = "/_create", method = RequestMethod.POST)
	    public ResponseEntity<NoDuesCreateResponse> noDuesV1CreatePost(@Valid @RequestBody NoDuesCreateRequest noDuesCreateRequest) {
         
		 System.out.println("PropertyId = "+noDuesCreateRequest.getNoDuesDetails().getPropertyId());
         System.out.println("Applicanttype = "+noDuesCreateRequest.getNoDuesDetails().getApplicanttype());
         System.out.println("CreatedBy = "+noDuesCreateRequest.getNoDuesDetails().getCreatedBy());
         System.out.println("Reason = "+noDuesCreateRequest.getNoDuesDetails().getReason());
         System.out.println("Remarks = "+noDuesCreateRequest.getNoDuesDetails().getRemarks());
         System.out.println("SewageId = "+noDuesCreateRequest.getNoDuesDetails().getSewageId());
         System.out.println("WaterId = "+noDuesCreateRequest.getNoDuesDetails().getWaterId());
         
         
		 NoDuesDetails noDuesDetails = noDuesService.initiateTransaction(noDuesCreateRequest);
	        ResponseInfo responseInfo = ResponseInfoFactory.createResponseInfoFromRequestInfo(noDuesCreateRequest.getRequestInfo(), true);
	        NoDuesCreateResponse response = new NoDuesCreateResponse(responseInfo, noDuesDetails);
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }
	
}
