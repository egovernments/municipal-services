package org.egov.nod.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class NoDuesRepository {

	 private final JdbcTemplate jdbcTemplate;
     private static final NoDuesRowMapper rowMapper = new NoDuesRowMapper();

     @Autowired
     NoDuesRepository(JdbcTemplate jdbcTemplate) {
         this.jdbcTemplate = jdbcTemplate;
     }
}
