package org.egov.nod.service;


import org.egov.nod.models.NoDuesDetails;
import org.egov.nod.repository.NoDuesRepository;
import org.egov.nod.validator.NoDuesValidator;
import org.egov.nod.web.models.NoDuesCreateRequest;
import org.egov.nod.web.models.RequestInfo;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Producer;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NoDuesService {
	
	    private NoDuesValidator validator;
	    private Producer producer;
	    private NoDuesRepository noDuesRepository;
	   
	
	
	public NoDuesDetails initiateTransaction(NoDuesCreateRequest noDuesCreateRequest) {
       // validator.validateCreateTxn(noDuesCreateRequest);

        // Enrich transaction by generating txnid, audit details, default status
//        enrichmentService.enrichCreateTransaction(transactionRequest);

        RequestInfo requestInfo = noDuesCreateRequest.getRequestInfo();
        NoDuesDetails transaction = noDuesCreateRequest.getNoDuesDetails();

      
        // Persist transaction and transaction dump objects
    //    producer.push(appProperties.getSaveTxnTopic(), new org.egov.pg.models.TransactionRequest(requestInfo, transaction));
    //    producer.push(appProperties.getSaveTxnDumpTopic(), new TransactionDumpRequest(requestInfo, dump));

        return transaction;
    }
	
	
	

}
