package org.egov.nod.web.models;




import javax.validation.Valid;

import org.egov.nod.models.NoDuesDetails;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NoDuesCreateResponse {
	 @JsonProperty("ResponseInfo")
	    @Valid
	    private ResponseInfo responseInfo;

	    @JsonProperty("NoDuesDetails")
	    @Valid
	    private NoDuesDetails noDuesDetails;
}
