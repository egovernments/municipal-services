package org.egov.nod.models;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NoDuesDetails {

	
	@JsonProperty("propertyId")
	@NotNull
	private String propertyId;
	
	
	@JsonProperty("WaterId")
	@NotNull
	private String WaterId;
	
	@JsonProperty("SewageId")
	@NotNull
	private String SewageId;
	
	@JsonProperty("Remarks")
	@NotNull
	private String Remarks;
	
	@JsonProperty("Reason")
	@NotNull
	private String Reason;
	
	
	@JsonProperty("createdDate")
	@NotNull
	private String createdDate;
	
	
	@JsonProperty("createdBy")
	@NotNull
	private String createdBy;
	
	
	
	@JsonProperty("applicanttype")
	@NotNull
	private String applicanttype;
	
	
	
	
	
	@JsonProperty("documents")
	@Valid
	private Set<Document> documents = new HashSet<>();
	
	
	
	
}
