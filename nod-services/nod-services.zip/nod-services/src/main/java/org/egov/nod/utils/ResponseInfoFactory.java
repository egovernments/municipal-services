package org.egov.nod.utils;


import org.egov.nod.web.models.RequestInfo;
import org.egov.nod.web.models.ResponseInfo;

public class ResponseInfoFactory {
	public static ResponseInfo createResponseInfoFromRequestInfo(final RequestInfo requestInfo, final Boolean success) {

        final String apiId = requestInfo != null ? requestInfo.getApiId() : "";
        final String ver = requestInfo != null ? requestInfo.getVer() : "";
        Long ts = null;
        if (requestInfo != null)
            ts = requestInfo.getTs();
        final String resMsgId = "uief87324"; // FIXME : Hard-coded
        final String msgId = requestInfo != null ? requestInfo.getMsgId() : "";
        final ResponseInfo.StatusEnum responseStatus = success ? ResponseInfo.StatusEnum.SUCCESSFUL : ResponseInfo.StatusEnum.FAILED;

        return ResponseInfo.builder().apiId(requestInfo.getApiId()).ver(requestInfo.getVer()).ts(requestInfo.getTs()).resMsgId(requestInfo.getResMsgId()).msgId(requestInfo.getMsgId())
                .build();
    }

}
