package org.egov.nod.repository;

import static java.util.Objects.isNull;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.transaction.Transaction;

import org.egov.nod.models.AuditDetails;
import org.egov.nod.models.NoDuesDetails;
import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NoDuesRowMapper implements RowMapper<NoDuesDetails> {

    private static ObjectMapper objectMapper = new ObjectMapper();
  
    @Override
    public NoDuesDetails mapRow(ResultSet resultSet, int i) throws SQLException {

        AuditDetails auditDetails = new AuditDetails();
        return NoDuesDetails.builder()
               // .txnId(resultSet.getString("txn_id"))
               // .txnAmount(resultSet.getString("txn_amount"))
               // .txnStatus(Transaction.TxnStatusEnum.fromValue(resultSet.getString("txn_status")))
               /// .txnStatusMsg(resultSet.getString("txn_status_msg"))
               // .gateway(resultSet.getString("gateway"))
               // .billId(resultSet.getString("bill_id"))
               // .productInfo(resultSet.getString("product_info"))
               // .user(user)
               // .tenantId(resultSet.getString("tenant_id"))
               // .gatewayTxnId(resultSet.getString("gateway_txn_id"))
               // .gatewayPaymentMode(resultSet.getString("gateway_payment_mode"))
               // .gatewayStatusCode(resultSet.getString("gateway_status_code"))
               // .gatewayStatusMsg(resultSet.getString("gateway_status_msg"))
               // .receipt(resultSet.getString("receipt"))
               // .consumerCode(resultSet.getString("consumer_code"))
               // .additionalDetails(additionalDetails)
               // .taxAndPayments(taxAndPayments)
             //   .auditDetails(auditDetails)
                .build();
    }
}
